**Documentation**

You can go directly to [doxygen documentation](http://www.jakesee.com/docs/ganttchart) or visit my [blog](http://www.jakesee.com/net-c-winforms-gantt-chart-control/) for further information.

_Version 1.1, 1.2, 1.3_

**Basic Usage: Create Chart and Adding Tasks**

{{
public Form1()
{
    InitializeComponents();
    var manager = new ProjectManager();
    var task = new Task() { Name = "Hello World" };
    manager.Add(task);
    var chart = new Chart();
    chart.Init(manage);
    
    this.Controls.Add(chart);
    // this.AutoScroll = true; // this is no longer required
}
}}

**Common Task Manipulation**
You can manipulate the task through code using various methods in the ProjectManager:

{{
// Set task durations
_mManager.SetDuration(wake, 3);
// Give the Tasks some organisation, setting group and
// precedents e.g. make "wake" task a subtask under "work"
_mManager.Group(work, wake);
// Setting task dependencies e.g. make "wake" task a precedent of "brush teeth" task
_mManager.Relate(wake, teeth);
// Assigning Resources e.g. add "jake" resource to "wake" task
_mManager.Assign(wake, jake);
// splitting a tasks e.g. split the "pack up" task into 2 new tasks
_mManager.Split(pack, new MyTask(_mManager), new MyTask(_mManager), 2);
// set some tooltips to show the resources in each task
// e.g. set a tooltip on the "wake" task
_mChart.SetToolTip(wake, string.Join(", ", _mManager.ResourcesOf(wake).Select(x => (x as MyResource).Name)));
}}

**Custom Task Data: Different colors for every tasks**
You can change the default task appearance for all task, or as in here change individual task color as a demo for adding custom business data to tasks.

{{
public partial class ExampleSimple : Form
{
  ProjectManager _mProject;
  public ExampleSimple()
  {
    InitializeComponent();
    _mProject = new ProjectManager();
    _mProject.Add(new Task() { Name = "New Task" });
    _mProject.Add(new ColoredTask() { Name = "Purple Task", Color = Color.Purple });
    _mProject.Add(new ColoredTask() { Name = "Gold Task", Color = Color.Gold });
    _mChart.Init(_mProject);
    // Custom behavior on paint task
    _mChart.PaintTask += (s, e) =>
    {
        ColoredTask ctask = e.Task as ColoredTask;
        if (ctask != null)
        {
            var format = new TaskFormat();
            format = e.Format;
            format.BackFill = new SolidBrush(ctask.Color);
            e.Format = format;
        }
    };
		
    // Grab custom data for tasks
    _mChart.TaskSelected += (s, e) =>
    {
        ColoredTask ctask = e.Task as ColoredTask;
        if (ctask != null)
        {
            MessageBox.Show("Selected " + ctask.Color.ToString());
        }
    };
  }
}

// Custom task with business data
public class ColoredTask : Task
{
    public ColoredTask() : base() {}
    public Color Color { get; set; }
}
}}